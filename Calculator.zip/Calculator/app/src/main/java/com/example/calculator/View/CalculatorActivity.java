package com.example.calculator.View;

import android.os.Bundle;

import com.example.calculator.R;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class CalculatorActivity extends AppCompatActivity {

    private TextView Calc_Input;
    private ViewGroup Calc_Buttons;

    private double num1;
    private double num2;
    private double answer;
    private char operation;
    private boolean next_num;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Calc_Input = (TextView) findViewById(R.id.Calc_Input);
        Calc_Buttons = (ViewGroup) findViewById(R.id.Calc_Buttons);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onButtonClicked(View v) {
        Button button = (Button) v;
        String function = button.getTag().toString();

        // When a button is clicked, the app determines what the button says, and performs
        // an action based on that.

        if (function.equals("C")){
            Calc_Input.setText("0");
            Cancel();
        }

        else if (function.equals("Back") && !Calc_Input.getText().equals("0")){
            Back();
        }

        else if (function.equals("+") || function.equals("-") || function.equals("X") || function.equals("/")){

            if(operation != ' '){
                // This sequence refers to the event that a second operation is performed,
                // as opposed to the equals button being pressed. This is for operations
                // such as 2 + 2 + 2 = 6
                num2 = Double.parseDouble(Calc_Input.getText().toString());
                operation = function.charAt(0);
                num1 = Calculate(num1, num2, operation);
                Calc_Input.setText(String.valueOf(num1));
                num2 = 0;
            }
            else {
                // This sequence refers to a normal input, such as 2 + 2 = 4
                num1 = Double.parseDouble(Calc_Input.getText().toString());
                operation = function.charAt(0);
            }
            next_num = true;

        }

        else if (function.equals("=")){
            // When the operation is ready to be performed, "=" is pressed, and the math is done
            if (next_num == true)
                Calc_Input.setText("ERROR");
            else {
                num2 = Double.parseDouble(Calc_Input.getText().toString());
                answer = Calculate(num1, num2, operation);
                Calc_Input.setText(String.valueOf(answer));
            }

            if (num2 == 0)
                Calc_Input.setText(String.valueOf(num1));

            // Prepare calculator for next operation
            num1 = 0;
            num2 = 0;
            operation = ' ';
            answer = 0;
            next_num = true;
        }

        else if (function.equals("+/-")){
            Pos_Neg();
        }

        else{
            num_input(function);
        }
    }

    public void num_input(String input){
        if ((Calc_Input.getText().toString().equals("0") && !input.equals(".")) || next_num == true){
            // If the text only says "0", and the input is not ".", the input replaces the text.
            // This is also done if "next_num" is true, which refers to whether the new text is
            // Supposed to have anything to do with the previous text, if it is true, this is a
            // new number
            Calc_Input.setText(input);
            next_num = false;
        }
        else {
            // Otherwise, the input is added onto the text
            Calc_Input.setText(Calc_Input.getText() + input);
        }
    }

    public void Cancel(){
        // Reset calculator to beginning state
        num1 = 0;
        num2 = 0;
        operation = ' ';
        answer = 0;
        Calc_Input.setText("0");
        next_num = false;
    }

    public void Back(){
        String backspace = Calc_Input.getText().toString();
        if(backspace.substring(0, backspace.length() - 1).equals("")){
            // Calculator's default text should be 0"
            Calc_Input.setText("0");
        }
        else{
            // Deletes last character in input
            Calc_Input.setText(backspace.substring(0, backspace.length() - 1));
        }
    }

    public void Pos_Neg(){
        String Newtext = Calc_Input.getText().toString();

        if(Calc_Input.getText().charAt(0) == '-'){
            // Undoes negative symbol if button is pressed while it is present
            Calc_Input.setText(Newtext.substring(1, Newtext.length()));
        }
        else if(!Newtext.equals("0")){
            // 0 cannot be negative
            Calc_Input.setText("-" + Calc_Input.getText());
        }
    }

    public double Calculate(double num1, double num2, char operation) {
        // The operation performed is dependent on the character placed in
        if (operation == '+')
            return (num1 + num2);
        else if (operation == '-')
            return (num1 - num2);
        else if (operation == 'X')
            return (num1 * num2);
        else if (operation == '/')
            return (num1 / num2);
        else
            return 0;
    }
}
