package com.example.calculator.Presenter;

public class CalculatorPresenter implements Presenter {

    private CalculatorView view;

    public CalculatorPresenter(CalculatorView view){
        this.view = view;
    }

    public void onCreate(){

    }

    public void onPause(){

    }

    public void onResume(){

    }

    public void onDestroy(){

    }
}
